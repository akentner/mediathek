<?php
require_once dirname(dirname(__FILE__)) . DIRECTORY_SEPARATOR . 'TestSetup.php';

class Shanty_Paginator_TestSetup extends Shanty_TestSetup
{
}