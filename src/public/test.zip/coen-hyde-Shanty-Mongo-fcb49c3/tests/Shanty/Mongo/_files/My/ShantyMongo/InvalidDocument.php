<?php

class My_ShantyMongo_InvalidDocument
{
	
}