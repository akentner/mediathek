<?php

require_once 'Shanty/Mongo/DocumentSet.php';

class My_ShantyMongo_Users extends Shanty_Mongo_DocumentSet
{
	
}