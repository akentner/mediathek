<?php

require_once 'Shanty/Mongo/Document.php';

class My_ShantyMongo_Abstract extends Shanty_Mongo_Document
{
	
}