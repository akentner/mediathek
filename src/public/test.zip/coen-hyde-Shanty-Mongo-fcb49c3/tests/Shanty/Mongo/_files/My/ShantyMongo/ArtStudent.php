<?php

require_once 'My/ShantyMongo/Student.php';

class My_ShantyMongo_ArtStudent extends My_ShantyMongo_Student
{

}